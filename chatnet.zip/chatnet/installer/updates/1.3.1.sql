UPDATE `cn_settings` SET `value` = '1.3.1' WHERE `cn_settings`.`name` = 'current_version';
